#include <iostream>
#include <typeindex>
#include <typeinfo>
#include <cxxabi.h>
#include <assert.h>

#include <map>

std::ostream &
operator<<(std::ostream &os, const std::type_info &ti) {
    int ec;
    char *p = abi::__cxa_demangle(ti.name(), 0, 0, &ec);
    assert(ec == 0);
    std::string s(p);
    free(p);
    return os << s;
}

class Counter {
    private:
        struct Counts {
            std::size_t constructed = 0;
            std::size_t destructed = 0;
        };
    protected:
        Counter(const std::type_info &ti) : ti(ti) {
            // std::cerr << "Object of type " << ti << " instantiated." << std::endl;
            // Here, need to increment a counter corresponding to derived object type.
            s_counts[ti].constructed++;
        }
        ~Counter() {
            // std::cerr << "An object was destroyed." << std::endl;
            // Here, need to decrement a counter corresponding to the derived object type.
            s_counts[ti].destructed++;
        }
    private:
        const std::type_info &ti;
    public:
        static std::size_t total_constructed(const std::type_info &ti);
        static std::size_t total_destructed(const std::type_info &ti);
        static std::size_t total_current(const std::type_info &ti);
    private:
        static std::map<std::type_index, Counts> s_counts;
};

std::size_t
Counter::total_constructed(const std::type_info &ti) {
    return s_counts[ti].constructed;
}

std::size_t
Counter::total_destructed(const std::type_info &ti) {
    return s_counts[ti].destructed;
}

std::size_t
Counter::total_current(const std::type_info &ti) {
    return s_counts[ti].constructed - s_counts[ti].destructed;
}

std::map<std::type_index, Counter::Counts> Counter::s_counts;

class A : public virtual Counter {
    public:
        A() /* May need to add something here. */ : Counter(typeid(*this)) { /* Don't add anything to ctor body. */ }
    // Don't add anything else to this class.
};

class B : public A, public virtual Counter {
    public:
        B() /* May need to add something here. */ : Counter(typeid(*this)) { /* Don't add anything to ctor body. */ }
    // Don't add anything else to this class.
};

class C : public A, public virtual Counter {
    public:
        C() /* May need to add something here. */ : Counter(typeid(*this)) { /* Don't add anything to ctor body. */ }
    // Don't add anything else to this class.
};

class D : public B, public C, public virtual Counter {
    public:
        D() /* May need to add something here. */ : Counter(typeid(*this)) { /* Don't add anything to ctor body. */ }
    // Don't add anything else to this class.
};

void
stats(const std::type_info &ti) {
    std::cout << "Type " << ti << ":" << std::endl;
    std::cout << "    " << Counter::total_constructed(ti) << " total constructed." << std::endl;
    std::cout << "    " << Counter::total_destructed(ti) << " total destructed." << std::endl;
    std::cout << "    " << Counter::total_current(ti) << " total currently instantiated." << std::endl;
}

void
stats_all() {
    stats(typeid(A));
    stats(typeid(B));
    stats(typeid(C));
    stats(typeid(D));
}

int main() {

    std::cout << "---- Point 1 ----" << std::endl;
    stats_all();
    
    {
        A a1;
        B b1;
        C c1;
        D d1;
    }

    std::cout << "---- Point 2 ----" << std::endl;
    stats_all();

    {
        A a1, a2;
        B b1, b2;
        C c1, c2;
        D d1, d2;

        A *A_array = new A[10];
        B *B_array = new B[10];
        C *C_array = new C[10];
        D *D_array = new D[10];

        std::cout << "---- Point 3 ----" << std::endl;
        stats_all();

        delete [] A_array;
        delete [] B_array;
        delete [] C_array;
        delete [] D_array;
    }

    std::cout << "---- Point 4 ----" << std::endl;
    stats_all();
}
